%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
6/9/2001. See end of file for history.

	Spatiotemporal and Weak Model ICA
	---------------------------------

  	Jim Stone, John Porrill and Neil Porter, 
	Psychology Department, Sheffield University, UK.

Contents
--------

	Overview of Program
	Unpacking the STICA Tar File
	Computational Requirements
	Running Program Demonstration
	Summary of Parameters
	User Guide
	Example Output
	Copyright
	Contact Information.
	Acknowledgements

Overview of Program
-------------------

Independent component analysis (ICA) is a method for decomposing
mixtures of source signals into statistically independent signals
(ICs). It can be used for spatial and temporal signals, and has been
applied to EEG/ERP cite and fMRI data. An introduction to ICA can be
found at http://www.cnl.salk.edu/~tewon/ICA/preface.html.

This program implements algorithms presented in a tehnical report,
"Regularisation Using Spatiotemporal Independence and Predictability",
(JV Stone and J Porrill, Computational Neuroscience Technical Report
number 1, Psychology Department, Sheffield University).  This can be
obtained from http://www.shef.ac.uk/~pc1jvs.

The code included in this program is written in MatLab (version
5.2.1), and tested on a Macintosh, Unix and PC.

The program is set up to process sequences of 2D images (e.g. fMRI
data), but could be adapted for other data. The program can be run in
several modes:

Spatial ICA: This decomposes an image sequence into a set of spatially
independent images and a corresponding set of dual temporal signals
(see cite Mck).

Temporal ICA: This decomposes an image sequence into a set of
temporally independent time courses and a corresponding set of dual
spatial images.

Spatiotemporal ICA: This decomposes an image sequence into a set of
spatial images and a corresponding set of time courses such that
signals in both sets are maximally independent.

Weak Model ICA: This regularises solutions found by ICA. The form of
weak model used here assumes that underlying sources signals or their
dual signals vary smoothly over time. This can be shown to improve the
nature of solutions found by ICA.

Skew_ICA: Use skew pdf, appropriate for images.

Note: This package is intended for people who want to see a quick
demonstration of ICA-related techniques, and for those who want to
adapt the code for their own uses. Programs with a more tutorial style
can be obtained via the web address given above.

Unpacking the STICA Tar File
----------------------------

The compressed tar file is called STICA_skew_demo.tar.
It can be unpacked on a unix machine using the command:

	tar -xvf STICA_skew_demo.tar

This process creates a new directory STICA_skew_demo which contains the
following files directories:

README.txt			- This file.
STICA				- Top level directory.
STICA_CORE			- Main code.
STICA_UTIL			- Utilities.
STICA_CONJ_GRAD		- Conjugate gradient optimisation.
STICA_FIND_VU_FAST	- Weak model code.
STICA_NIPS_ADDD_ONS	- Skew pdf code.

Computational Requirements
--------------------------

The code included in this program is written in MatLab (version 5.2).

Demonstration Program 
---------------------

Set current directory to STICA_demo and then ensure that matlab can
access the required files by running typing:
	
	jsetpath;

This adds three direectories to the current path.
The demonstration program demonstration can then be run by typing:

	stica_demo;

to the matlab command line (stica_demo is in STICA_CORE). 
The program makes synthetic fMRI data, and then
applies skew spatiotemporal ICA to it.  
All of the code required to run the demonstration is in three directories.

Try setting the mode parameter to 's' (spatial ICA) then 't' (temporal
ICA) then 'st' (spatiotemporal ICA). 
Only spatiotemporal ICA with skew spatial pdf model ('st' with SKEW_PDF_s=1) 
recovers the original source signals.

Summary of Parameters
---------------------

The following parameters can be set from the file ica_demo.m.

--------------------------------------------------------------
Variable		Type			Description
--------------------------------------------------------------
RAND_SEED		[int]			Random number seed.
mode 			['s','t','st'] 	ICA: spatial, temporal or spatiotemporal.
alpha			[real]			Ratio of spatial to temporal independence for stICA.
wm_sm 			[0,1] 			Add temporal smoothing weak model to sICA, tICA, or stICA.
beta			[real]			Ratio of [spatial,temporal] independence for weak model.
plot_inverval	[int]			Number of function evalutions between plotting results.
SKEW_PDF_s	 	[0,1]        	Use skew pdf for spatial model (if set, ignore hi_kurt_s & lo_kurt_s)
SKEW_PDF_t	 	[0,1]        	Use skew pdf for temporal model (if set, ignore hi_kurt_t & lo_kurt_t)
s_kurtosis		['hi','lo']		Kurtosis of spatial ICs - used with sICA and stICA.
t_kurtosis		['hi','lo']		Kurtosis of temporal ICs - used with tICA and stICA.
s_hi_kurt		[0,1]			Specify kurtosis of indvidual ICs (overrides s_kurtosis).
t_hi_kurt		[0,1]			Specify kurtosis of indvidual ICs (overrides t_kurtosis).
neig			[int]			Number of eigenvectors to use as input to ICA.
X				[3D matrix]		Input data: matrix of image sequences, used to obtain P and Q.
P				[2D matrix]		Matrix of neig temporal eigenvectors.
Q				[2D matrix]		Matrix of neig spatial eigenvectors.
W0				[2D matrix]		Intiial (neig x neig) unmixing matrix. 
W1				[2D matrix]		Final (neig x neig) unmixing matrix. 
S1				[2D matrix]		Matrix of spatial signals found by ICA.
T1				[2D matrix]		Matrix of temporal signals found by ICA.
%---------------------------------------------------------------------------------------

User Guide
----------

The program output is demonstrated below.  The optimisation routine
prints various parameters, of which only f and |g| are of interest
here. f is the value of the function being minimised (estimated
negative of entropy of recovered ICs) , and |g| is the magnitude of
its gradient.

Example Output
--------------

In its current state the program's text output should appear as follows
on an SGI Indy R4400:

>> stica_demo

SETTING RANDOM NUMBER SEEDS TO 111

Using SPATIOTEMPORAL_ICA

pcs(:,1): jsize =  1600  1 
Figures 1 and 2 are spatial and temporal eigenvectors.
pct: jsize =  1600  4 
P: jsize =  1600  4 
Q: jsize =  1600  4 
stica: V0: jsize =  4  4 
stica: d0: jsize =  1  4 
THIS IS CONJGRAD ...
n=     1 |rho=    1.262030 lambda=    0.500000 | f=     13.8257 | |g|=     1.71974 step_len=    0.0576317
n=    11 |rho=    0.948245 lambda=    0.003906 | f=     5.86142 | |g|=   0.0472978 step_len=     0.441126
n=    21 |rho=    0.710472 lambda=    0.000015 | f=     5.77516 | |g|=  0.00875179 step_len=     0.142077
n=    31 |rho=    0.539425 lambda=    0.000000 | f=     5.76549 | |g|=  0.00308112 step_len=     0.088801
... stica done.
Elapsed time = 40.6  secs.

Copyright
---------

No part of this program should be used in any commercial application.
Acknowledgement of use by others should cite the technical report
associated with this software (i.e. "Regularisation Using
Spatiotemporal Independence and Predictability", by JV Stone and J
Porrill, Computational Neuroscience Technical Report number 1
Psychology Department, Sheffield University.).

Contact information
-------------------
,----------------------------------------------------------------------.
|    Jim Stone,  Wellcome Research Fellow, Sheffield University        |
+----------------------------------------------------------------------+
| Psychology Department, | Email:           j.v.stone@sheffield.ac.uk  |
| Sheffield University   | Tel (direct):    +44 114 222 6522           |
| Sheffield, S10 2UR,    | Fax:             +44 114 276 6515           |
| England.               | http://www.shef.ac.uk/~pc1jvs/     	       |
`-----------------------------------------------------------------------'

Acknowledgements
----------------
JV Stone is supported by the Wellcome Trust.

History
--------

10/5/00

Made wm_sm variable actually switch temporal weak model on and off.

7/9/01

Updated to include skew-pdf.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

