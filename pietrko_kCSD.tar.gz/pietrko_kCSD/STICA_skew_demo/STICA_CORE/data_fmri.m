% data_fmri;

% function zs = go();

% global disparities W W1 W2 Data disparities old_W Data1 zs num_mixtures;

jrand_set_seed(9);

% Use data_init for first call.
% load 'udv_T_320.mat';
%   D       320x320       819200  double array (global)
%   U      3339x320      8547840  double array (global)
%   V       320x320       819200  double array (global)
%   nc        1x1              8  double array (global)
%   nr        1x1              8  double array (global)
%   
% data_init_nohid; 
% Data_orig = Data;

num_mixtures=16; % Num mixtures.
V=V;
Data = V(:,1:num_mixtures);

plot(Data(:,1)); title('First mixture'); drawnow;pr;

jsize(Data,'Data'); % 320 4 
[num_ip_vecs num_mixtures]=size(Data);
timax_init_nohid; 

wts_init_nohid;
find_one_source; 

z1=zs;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Extract another source.
pr;
zs=z1;

% wts_init_nohid;
% Data=remove_signal(zs',Data');
% for i=1:0
%	Data = remove_signal(zs'+ 0.5*std(zs)*randn(size(zs')), Data);
%end;Data=Data';

imax=100;
zz = zeros(320,imax);
for i=1:imax
Data=remove_signal(zs',Data');Data=Data';
wts_init_nohid;
find_one_source; z2=zs;
zz(:,i)=zs;
fprintf('i=%d\n',i);
end;

return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('On old data get r=%f\n',r);
[Data disparities] = jmake_stereoW(image_len,num_ip_vecs,noise,max_disp);
FoneD(W,Data);
r=jcorr(zs,disparities);
fprintf('On new data get r=%f\n',r);



