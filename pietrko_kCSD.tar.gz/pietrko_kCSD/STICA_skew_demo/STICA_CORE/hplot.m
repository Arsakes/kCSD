function hplot(yt,override,fig_num,str);

global num_funevals plot_inverval;
global neig;
global num_linesearches;
global temp_t;
global SPATIAL_ICA TEMPORAL_ICA SPATIOTEMPORAL_ICA;
global mode;

if nargin<2 override=0; end;


if override==1 | ( rem(num_linesearches,plot_inverval)==0 & (temp_t ~= num_linesearches) )

if nargin<3
	fig_num=4;
end;

if nargin<4
if SPATIAL_ICA
	str = 'Dual Temporal #';
elseif TEMPORAL_ICA
	str =	'Temporal IC #';
elseif SPATIOTEMPORAL_ICA | TEMPORAL_ICA
	str = 'Temporal IC #';
end;
end;

% jsize(yt); %  1024  4

y1 = (yt(:,1));
[xb xa]=size(y1);
% jsize(y1);

jfig(fig_num); 
K=neig;
for kk=1:K
	subplot(K/2,2,kk); 
	ya=min(y1); yb = max(y1);
	plot(yt(:,kk)); axis([xa xb ya yb]);
	title([str, int2str(kk)]);  jset_yticklabel;  jset_xticklabel;
end;
	
drawnow;

end;
temp_t = num_linesearches;
