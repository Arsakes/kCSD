function [y, t] = tanh_deriv(x);

t=tanh(x);
y = 1-t.^2;
