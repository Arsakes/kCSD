function g = sticag(w, data)


[f, g] = sticafg(w, data);

