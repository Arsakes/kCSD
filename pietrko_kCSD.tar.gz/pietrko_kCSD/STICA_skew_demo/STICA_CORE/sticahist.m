function sticahist



m = 100;

n = 100;

k = 5;

alpha = 0.5;



% run rt_ica on synthetic data

% and histogram results



c = linspace(0, 1, 50); % histogram bins



nsamp = 50;

err1 = [];

err2 = [];

for i = 1:nsamp

    % synthetic data

    S = randk(m, k, 0.1);

    T = randk(n, k, 0.1);

    

    % mixed data

    A = randn(k, k);

    P = S*A;

    Q = T*inv(A');

   

    V = ica(P);

    E = A*V;

    err1(i) = maxcorr(E);

    figure(1); subplot(2, 1, 1);

    hist1(err1(1:i), 0, 1, 50);

    

    figure(1); subplot(2, 1, 2);

    V = stica(P, Q, alpha, V);

    E = A*V;

    err2(i) = maxcorr(E); 

    figure(1); subplot(2, 1, 2);

    hist1(err2(1:i), 0, 1, 50); 

end



% nicer histogram function



function hist1(y, y1, y2, nbin)

% histogram y using nbin bins in range y1 to y2

x = linspace(y1, y2, nbin+1); dx = x(2)-x(1);

x = x(1:nbin)+dx/2;

h = hist(y, x);

bar(x, h);

axis([y1 y2 0 max(h)]);

drawnow

