function show4sequences(seq,nr,nc,f,str);

fprintf('Time courses ...\n');
jfig(f); 

xmin=-1;
xmax=1;

[xb xa]=size(seq(:,1));

ya = -1;
yb = 1;

s1=seq(:,1);
s1=jnormalise_range(s1,xmin,xmax);
subplot(2, 2, 1); plot( s1 );  title([str ' 1']);axis([xa xb  ya yb]); axis tight

s2=seq(:,2);
s2=jnormalise_range(s2,xmin,xmax);
subplot(2, 2, 2); plot(  s2 ); title([str ' 2']);axis([xa xb  ya yb]); axis tight

s3=seq(:,3);
s3=jnormalise_range(s3,xmin,xmax);
subplot(2, 2, 3); plot(  s3 ); title([str ' 3']);axis([xa xb  ya yb]); axis tight

s4=seq(:,4);
s4=jnormalise_range(s4,xmin,xmax);
subplot(2, 2, 4); plot(  s4 ); title([str ' 4']);axis([xa xb  ya yb]); axis tight
