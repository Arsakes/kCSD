function [V, W, D]=get_VWD(w,data);

% Get spatial and temporal weight matrices.
% V=spatial (kxk), W=TEMPORAL (kxk), D=scalings.

global SPATIAL_ICA TEMPORAL_ICA SPATIOTEMPORAL_ICA;

[m, k] = size(data.P);
V = reshape(w(1:k*k), k, k); % V= kxk.

if SPATIOTEMPORAL_ICA
	w_scale =  w(k*k+1:k*k+k);
	D = diag( w_scale );
elseif (SPATIAL_ICA | TEMPORAL_ICA)
	D = diag(ones(1,k));
else
	error('get_VWD');
end;

W = inv(V')*D; % temporal.
% In paper it is Wt = inv(Ws') * inv(D');
% I think this is because we use Ws = inv(Wt') * inv(D') in this code.
