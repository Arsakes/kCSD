function [V, W, D, Bs, Bt]=get_VWDBsBt(w,data);

% Get spatial and temporal weight matrices.
% V=spatial (kxk), W=TEMPORAL (kxk), D=scalings, Bs= spatial BIAS, Bt=temporal bias.

global SPATIAL_ICA TEMPORAL_ICA SPATIOTEMPORAL_ICA;

[m, k] = size(data.P);
V = reshape(w(1:k*k), k, k); % V= kxk.

% A=reshape(w,k+3,k);V=A(1:k,1:k);w_scale =A(k+1,:);Bs=A(k+2,:);Bt=A(k+3,:);
 
if SPATIOTEMPORAL_ICA
	w_scale =  w(k*k+1:k*k+k);
	D = diag( w_scale );
elseif (SPATIAL_ICA | TEMPORAL_ICA)
	D = diag(ones(1,k));
else
	error('get_VWD');
end;

% Get penultimate row.
Bs = w(k*(k+1)+1:k*(k+1)+k);
% w is a col vector so ...
Bs=Bs';

% Get last row.
Bt = w(k*(k+2)+1:k*(k+2)+k);
% w is a col vector so ...
Bt=Bt';

W = inv(V')*D; % temporal.
% In paper it is Wt = inv(Ws') * inv(D');
% I think this is because we use Ws = inv(Wt') * inv(D') in this code.
