function [mixt, sm_sources, tm_sources] = datat_skew(nr, nc, nt)

% Each col of mixt contains an image.
% nr=20; nc=20; [m U V]=datat(nr,nc,nr*nc);

if(nr ~= nc) error('nr=/=nc'); end
n = nr;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MAKE DISC IMAGES.
[x, y] = meshgrid(linspace(-1, 1, n));

s1=rand(nr*nc,1)+0.5*randk(nr*nc,1,0.1); s1=s1(:);

s1=randk(nr*nc,1,0.1); s1=s1(:);
s2=randk(nr*nc,1,0.1);;s2=s2(:);
s3=randk(nr*nc,1,0.1);;s3=s3(:); 
s4=randk(nr*nc,1,0.1);s4=s4(:);
s_sources=[s1 s2 s3 s4];

y=randk(32,32,0.1,4);s_sources=reshape(y,32*32,4);

disc=0;
if disc
radius = 0.3;
X=-0.5;Y=-0.5;	im1 = make_disc_image(nr, nc, X,Y,radius);	im1=im1(:);
X=-0.5;Y=0.5;	im2 = make_disc_image(nr, nc, X,Y,radius);	im2=im2(:);
X=0.5;Y=-0.5;	im3 = make_disc_image(nr, nc, X,Y,radius);	im3=im3(:);
X=0.5;Y=0.5;	im4 = make_disc_image(nr, nc, X,Y,radius);	im4=im4(:);
ramp=linspace(-1,1,nt);   
im1=im1 +ramp';
s_sources = [im1 im2 im3 im4]; 
end;

noise_disc=1;
if noise_disc
nfac=0.5;
radius = 0.25;
nradius = 0.25;

X=-0.5;Y=-0.5;	im1 = make_disc_image(nr, nc, X,Y,radius);	
X=-0.5;Y=0.5;
im1 = (1-nfac)*im1+nfac*make_disc_noise_image(nr, nc, X,Y,nradius);	imagesc(im1);
im1=im1(:);

X=-0.5;Y=0.5;	im2 = make_disc_image(nr, nc, X,Y,radius);	
X=-0.5;Y=-0.5;	
im2 = (1-nfac)*im2+ nfac*make_disc_noise_image(nr, nc, X,Y,nradius); imagesc(im2);
im2=im2(:);

X=0.5;Y=-0.5;	im3 = make_disc_image(nr, nc, X,Y,radius);	
X=0.5;Y=0.5;	
im3 = (1-nfac)*im3+nfac*make_disc_noise_image(nr, nc, X,Y,nradius);	imagesc(im3);
im3=im3(:);

X=0.5;Y=0.5;	im4 = make_disc_image(nr, nc, X,Y,radius);	
X=0.5;Y=-0.5;	
im4 = (1-nfac)*im4+nfac*make_disc_noise_image(nr, nc, X,Y,nradius); imagesc(im4);
im4=im4(:);

%ramp=linspace(-1,1,nt);   
%im1=im1 +ramp';
s_sources = [im1 im2 im3 im4]; 
end;

sins=0;
if sins
[x, y] = meshgrid( linspace(0, 1, nr), linspace(0, 1, nc) );
% (2) 3 5 7 9 11 13
im1 = sin(2*pi*2*x);im1=im1(:);
im2 = sin(2*pi*3*y);im2=im2(:);
im3 = sin(2*pi*5*y);im3=im3(:);
im4 = sin(2*pi*4*x) .* sin(2*pi*5*y);im4=im4(:);
end;

%ramp = x*y';
% jminmax(ramp(:)) 0 16

%ramp=ramp'./5;ramp=ramp(:);
% jsize(ramp); jsize(im3);
%im3=im3; % + ramp(:);
s_sources = [im1 im2 im3 im4]; 

% jsize(s_sources,'s_sources')
s_sources = zm_uvar_cols(s_sources);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MAKE TIME COURSES.

t = linspace(0, 1, nt);
t_sources = s_sources;

s1=randk(nr*nc,1,0.1); s1=s1(:);
s2=randk(nr*nc,1,0.1); s2=s2(:);
s3=randk(nr*nc,1,0.1); s3=s3(:); 
s4=randk(nr*nc,1,0.1); s4=s4(:);

t_sources=[s1 s2 s3 s4];

t_sources = rand(size(t_sources))-0.5;
% t_sources=sort(t_sources);

ss= sin(2*pi*3*t);
cc= cos(2*pi*3*t);
ramp=linspace(-1,1,nt);   
t1 = sin(2*pi*2*t); 
t2 = sin(2*pi*3*t);
t3 = sin(2*pi*5*t);  
t4 = sin(2*pi*11*t); % + 3*ramp;  ;   
%t_sources = [t1' t2' t3' t4']; 

% SKEW T.
SKEW_T=1;
if SKEW_T
t=t_sources;
%jminmax(t);
%jfig(100);imagesc(t);drawnow;pr;
ta=(t<0).*t;
ta=ta.^3;
tb = (t>=0).*t;
tb=tb.^2;
%jfig(101);imagesc(ta);drawnow;pr;
%jfig(102);imagesc(tb);drawnow;pr;
t=ta+tb;
t_sources=t;
%jfig(103);imagesc(t);drawnow;
end;
%jsize(t_sources,'t_sources')
t_sources = zm_uvar_cols(t_sources);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DISPLAY SOURCES.

jfig(100);
subplot(2, 2, 1); hist( t(:,1),100 );
subplot(2, 2, 2); hist( t(:,2),100 );
subplot(2, 2, 3); hist( t(:,3),100 );
subplot(2, 2, 4); hist( t(:,4),100 );

show4sequences(t_sources,nr,nc,2,'Source');
show4images(s_sources,nr,nc,1,'Source');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INSERT CORRELATIONS BETWEEN SPATIAL SOURCES.

a = 0.0;
sm = (1-a)*eye(4) + a*randn(4,4);
% MIX sources.
sm_sources = s_sources*sm;
p=1; % p=1 => no effect.

% Add Gauss noise to spatial sources.
noise_sources = randn(size(sm_sources));
q=1;
noise_sources = sign(noise_sources).* (abs(noise_sources).^q);
noise_sources = zm_uvar_cols(noise_sources);
noise_fac = 0.0;
sm_sources = (1-noise_fac).*sm_sources + noise_fac.*noise_sources;

sm_sources = sign(sm_sources).* (abs(sm_sources).^p);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% INSERT CORRELATIONS BETWEEN TEMPORAL SOURCES.

sm = (1-a)*eye(4) + a*randn(4,4);
tm_sources = t_sources*sm;
p=1/p;
tm_sources = sign(tm_sources).* (abs(tm_sources).^p);

% Add Gauss noise to temporal sources.
% noise_sources = randn(size(tm_sources));
tfac=0.0;
noise_fac = 0;
noise_fac = noise_fac+tfac;
tm_sources = (1-noise_fac).*tm_sources + noise_fac.*noise_sources;

% DISPLAY CORRELATED SOURCES.

show4sequences(tm_sources,nr,nc,3,'Sources');
show4images(sm_sources,nr,nc,4,'Sources');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MAKE MIXTURES.

mixt = sm_sources*t_sources';
% Add noise to mixtures ...
mixt = mixt; % + randn(size(mixt))*100;
mixt = zm_uvar_cols(mixt);
% show4images(mixt,nr,nc,4,'Mixture');

show_mixtures=0;
if show_mixtures
jfig(40);
for t=1:nt
	pnshow( reshape(mixt(:,t), nr, nc) );drawnow;
end;
end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
