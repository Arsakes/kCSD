function hplos(ys,override);

% SPATIAL
%	plot spatial IC's

global SPATIAL_ICA TEMPORAL_ICA SPATIOTEMPORAL_ICA;
global nr nc;
global num_funevals plot_inverval;
global neig;
global num_linesearches;
global temp_s;
global SPATIAL_ICA TEMPORAL_ICA SPATIOTEMPORAL_ICA;

if nargin==1	override=0; end;

if override==1 | ( rem(num_linesearches,plot_inverval)==0 & (temp_s ~= num_linesearches) )

if TEMPORAL_ICA
		str = 'Dual Spatial #';
elseif SPATIOTEMPORAL_ICA | SPATIAL_ICA
		str = 'Spatial IC #';
end;

jfig(3);
K=neig;
for k = 1:K
	subplot(K/2, 2, k);
	pnshow( reshape(ys(:, k), nr, nc) );
	title( [str, int2str(k)] );
	axis on; axis square;   jset_yticklabel;jset_xticklabel; 
end
	
drawnow;

end;
temp_s = num_linesearches;
