function [f, g] = wmfg(w, data)

% This is reduced version of wmicafg - it only gets wm f and g.
% w = 1D spatial weight matrix.

k = data.k; 		% num eigs.
W = reshape(w, k, k); 
Wit = inv(W'); % Find temporal matrix - no scalings required.
P = data.P; 
n = size(P, 1); % P = [n K] - so data in K cols.
%Q = data.Q;
% S = P*W;
% T = Q*Wit; % jsize(T,'T');pr; 360x4

nC = data.nC; % Num wm constraints - only one per wt vec.

C1 = data.C1;
C2 = data.C2;
a = data.alpha;

% B & S entropy & gradient.
% H  = -cmeansech2(S)-log(abs(det(W)));
% gH = 2/n*P'*ctanh(S)-inv(W');

% constraint information & gradient
C = 0; gC = 0;
%for i = 1:nC
    i=1;
	b = Wit(:, i); % b = weight col vec
	% jsize(b,'b'); pr; % 4  1 
	% v1 = b'*C1{i}*b; % PRE Var
    % v2 = b'*C2{i}*b; % POST Var
	v1 = b'*C1*b; % PRE Var
    v2 = b'*C2*b; % POST Var
    C  = C+0.5*(log(v1)-log(v2));
    % Gradient.
	%gC = gC + Wit'* (C2{i}/v2-C1{i}/v1) *b*b'; 
	gC = gC + Wit'* (C2/v2-C1/v1) *b*b'; 
	gC = gC'; % gC has same dims as gH.
%end

% fprintf('v1=%.3e v2=%.3e v1/v2=%.3e\n',v1,v2,v1/v2);

% combine ica and weak model
% f = a*H+(1-a)*C;
% g = reshape(a*gH+(1-a)*gC, k*k, 1);

f = C;
g = reshape(gC, k*k, 1);

% t = Q*b;jfig(200);plot(t); drawnow;
