function n=jversion();

v=version;
n=str2num(v(1));