function out = combin(val)

%

% out = combin(val)

%

% This function provides all possible combinations

% of unique numbers up to the specified value, where

% the sequence is irrelevant. For this function, the

% function `combrh.m' is needed.

%

% input:

%   val   : the maximal value

%

% output:

%   out   : matrix containing columns with all

%           possible combinations of unique numbers 

%           in the interval 1 ... val.

%

% example:

%   when the specified value equals 3, the

%   following output is generated:

%    _                                         _

%   |   1     1     1     1     2     2     3   |

%   |   0     2     2     3     0     3     0   |

%   |_  0     0     3     0     0     0     0  _|

%  

% 

% 11/19/1998, written by:

%   L.P. Evers (rens@wfw.wtb.tue.nl)

%   J.A.W. van Dommelen (hansd@wfw.wtb.tue.nl)

%   ------------------------------------------

%   Eindhoven University of Technology

%   Faculty of Mechanical Engineering

%   Section of Materials Technology

%   ------------------------------------------

%   P.O. Box 513, 5600 MB Eindhoven

%   The Netherlands

%   ------------------------------------------

%   http://www.mate.tue.nl/mate/

%   ------------------------------------------

%





val = round(abs(val));

out = combrh(1,val,zeros(val,0));

%

for i = 1:size(out,2),

  out(:,i) = [ nonzeros(out(:,i)); zeros(val - size(nonzeros(out(:,i)),1),1) ];

end