function jset_dot_size(N,h);

% jset_dot_size(7);

if nargin<2
	h = get(gca, 'Children');
end;
 
set(h,'MarkerSize',N); 

