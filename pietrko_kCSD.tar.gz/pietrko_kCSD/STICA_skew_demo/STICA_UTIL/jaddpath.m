function jaddpath(p);

eval(['addpath ' p]);
