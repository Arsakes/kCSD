function out = combrh(i, N, in1)

%

% out = combrh(i, N, in)

%

% This function is used only in combination 

% with the function `combin.m' and is self-

% calling after initiation.

% 

% 11/19/1998, written by:

%   L.P. Evers (rens@wfw.wtb.tue.nl)

%   J.A.W. van Dommelen (hansd@wfw.wtb.tue.nl)

%   ------------------------------------------

%   Eindhoven University of Technology

%   Faculty of Mechanical Engineering

%   Section of Materials Technology

%   ------------------------------------------

%   P.O. Box 513, 5600 MB Eindhoven

%   The Netherlands

%   ------------------------------------------

%   http://www.mate.tue.nl/mate/

%   ------------------------------------------

%





out = in1;

%

if isempty(in1),

  in1 = zeros(N,1);

  in2 = in1;

else,

  in2 = out(:,(size(out,2)));

end

%

for ii = i:N,

  out = [ out [ in2(1:(i-1),:);

                ii*ones(1,size(in2,2));

                zeros((N-i),size(in2,2))

              ]

        ];

  if ii < N,

    out = combrh((ii + 1),N,out);

  end

end