function jshow_pcs(pcs,nr,nc);

% One pc per column.
% Show each image as subplot.

[len neig] = size(pcs);
aa=sqrt(neig);
if rem(aa,1)==0 aa=aa; bb=aa; else aa=1;bb=neig; end;

for i = 1:neig
 	subplot(aa, bb, i);
	im1=reshape(pcs(:, i), nr, nc);
   	imagesc(im1); colormap(gray); axis off; axis square; 
	s=['PRINCIPAL component ' num2str(i)];
	title(s);
end




