function v=jrow_vec(n);

v = zeros(1,n);
