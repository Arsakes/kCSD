function jset_color_defaults(s);

% SEE ...
% COLORDEF Set color defaults.
%   COLORDEF WHITE or COLORDEF BLACK changes the color defaults on the
%   root so that subsequent figures produce plots with a white or
%   black axes background color.  The figure background color is
%   changed to be a shade of gray and many other defaults are changed
%   so that there will be adequate contrast for most plots.
%
%   COLORDEF NONE will set the defaults to their MATLAB 4 values.
%   The most noticable difference is that the axis background is set
%   to 'none' so that the axis background and figure background colors
%   are the same.  The figure background color is set to black.
%
%   COLORDEF(FIG,OPTION) changes the defaults of the figure FIG
%   based on OPTION.  OPTION can be 'white','black', or 'none'.
%   The figure must be cleared first (via CLF) before using this
%   variant of COLORDEF.
%
%   H = COLORDEF('new',OPTION) returns a handle to a new figure
%   created with the specified default OPTION.  This form of the
%   command is handy in GUI's where you may want to control the
%   default environment.  The figure is created with 'visible','off'
%   to prevent flashing.
%
%   See also WHITEBG.

%   Copyright (c) 1984-96 by The MathWorks, Inc.
%   $Revision: 1.13 $  $Date: 1997/01/23 20:02:22 $

colordef(s);