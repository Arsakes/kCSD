function yn=is_even(a)

yn = ~rem(a,2);