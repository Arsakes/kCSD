function m=jset_zero(m);

m = m .* 0;