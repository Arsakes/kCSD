function all=jremove_cols(all,cs);

