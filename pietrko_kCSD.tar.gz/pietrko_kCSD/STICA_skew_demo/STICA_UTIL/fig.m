function fig(n);

figure(n);