function xmax = jmax(array)

xmax = max(array(:));
