function len = jvec_len(v);

sum(v.*v);
