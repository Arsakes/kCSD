function p=jerf(z);

% Give correct erf function.

p = 0.5+erf(z/sqrt(2))/2;