function x=gso_w(col_vecs,x);

% 20/1/00 JVS.
% GSO for col vecs.
% x=col vec.
% Makes every col in col_vecs orthog to x by adjustin x (not col_vecs).
% NB: Can only work if cols of col_vecs are orthogonal.
% e.g. a=randn(4,3); b=gso(a); c=rand(4,1);d=gso_w(b,c);d'*b  % should be [0 0 0]
% See test_gso_w.m.

[n num_vecs]=size(col_vecs);

% Remove total projection of col vectors in U from x.
proj_sum = zeros(n,1);
for j=1:num_vecs
	uj = col_vecs(:,j);
	% Find amount of uj in x.
	if norm(uj)>0
		proj_sum = proj_sum + uj*(x'*uj)/(uj'*uj);
		% proj_sum = proj_sum + x*(uj'*x)/(x'*x);
	end;
end;  
x = x - proj_sum;
x = x/norm(x);

jdb=0;	
if jdb
	for j=1:num_vecs
		uj = col_vecs(:,j);
		x'*uj
	end;
	pr;
end
