function jset_view_angle(a);

set(gca,'Projection','perspective'); 
set(gca,'CameraViewAngleMode','manual'); 
set(gca,'CameraViewAngle',a); 