function xmin = jmin(array)

xmin = min(min(array));
