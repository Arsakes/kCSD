function b=jshuffle_cols(a);

[r c]=size(a);
newc = randperm(c);
b=a(:,newc);