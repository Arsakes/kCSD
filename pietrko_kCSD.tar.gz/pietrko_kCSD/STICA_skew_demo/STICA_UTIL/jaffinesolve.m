function [x, bias] = jaffinesolve(A,y); 

% Given y = Ax + bias solve for vector x and scalar bias.
% A = RxC matrix of R vector rows and C components.
% y = vector of R rows, x = vector of C rows (unknowns).
% bias = scalar.
% AND if y consists of >1 columns (ie>1 y vector) then
% x there will be one vector and one bias per column of x. 

[R C] = size(A);

% Append column of ones to A.
temp = ones(R,1);
B = [A,temp];

xb = B\y;

% Now xb = [x,b]

x = xb(1:C,:)';
bias = xb(C+1,:)';

% Find residual ...
%jsize(B);jsize(xb);
res = B*xb-y;
res = norm(res,2)/length(y);
fprintf('jaffinesolve residual = %f\n',res);

