fprintf('Press return to continue ...');
pause;
fprintf('..(return pressed)\n');