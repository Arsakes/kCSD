function v0 = jshift_region(v1,Rmin,Rmax);

% Find values of v1 at Rmin, Rmin+1 ... Rmax.

	shift = Rmin-round(Rmin);
	imin = round(Rmin);
	imax = round(Rmax);

% For testing  . . . 
%shift=-0.5;
%v1 = linspace(0,2*pi,360);
%v1 = sin(v1);
%imin = 11;
%imax = 200;

% Make non-integer indices for x0. 
x0 = linspace(imin,imax,(imax-imin+1));
x0 = x0+shift;

% Take sample of v1 that includes non-integer indices.
imax = imax+2;
imin = imin-2;
x1 = linspace(imin,imax,(imax-imin+1));
v1 = v1(imin:imax);

% Interpolate values of v1 at x0.
v0 = interp1(x1,v1,x0);

v0 = v0(1:length(v0));
v1 = v1(3:length(v1)-2);

% plot(v1); hold on; plot(v0,'r'); hold off;