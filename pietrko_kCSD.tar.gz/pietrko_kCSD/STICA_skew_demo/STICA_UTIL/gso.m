function U=gso(col_vecs,x);

% 20/1/00 JVS.
% GSO for col vecs.
% Makes all columns orthogonal and of unit length.
% If 2 args given then all cols in col_vecs is made orthog to col vector x.

if nargin>1
	col_vecs=[x col_vecs];
end;

[n num_vecs]=size(col_vecs);

U=zeros(n,num_vecs);

u1 = col_vecs(:,1);
u1 = u1/norm(u1);
U(:,1)=u1;

for i=2:num_vecs
	cvec=col_vecs(:,i);
	if norm(cvec)>0
	% Remove total projection of previous col vectors in U from cvec.
	proj_sum = zeros(n,1);
	for j=1:i-1
		uj = U(:,j);
		if norm(uj)>0
			proj_sum = proj_sum + uj*(cvec'*uj)/(uj'*uj);
		end;
	end;  
	uj = cvec - proj_sum;
	uj = uj/norm(uj);
	U(:,i)=uj;
	end; % norm
end;

if nargin>1
	U=U(:,2:num_vecs);
end;


