jcd('Jims_working_disc:Jims_Matlab5_files:');
cd
