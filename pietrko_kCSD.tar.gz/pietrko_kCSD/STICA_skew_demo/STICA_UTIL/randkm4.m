function ys = randkm4(m, n, a, P);

% randk for matlab4.
% Generate arrays with kurtosis.
% n = dim of matrix
% m = other dim of matrix
% P number of 2D matrices required
% a = amount of kurtosis (try -0.1 and 0.1).
% eg hist( randk(10000,0.1), 100 ); 
% ys=randk(10,10,0.1,5);

global us;

if nargin < 4 P = 1; end;
if nargin < 3 a=0.1; end;
if nargin==1 n=m; end;

umax = 4; % min and max values allowed.

us = randn(m, n);
ys = zeros(size(us));

	u = us(:,i);
	u = u(:);
	u = min(u,  umax);
	u = max(u, -umax);
	y = u.*(1+a*u.^2-(a/umax^2)*u.^4);
	y = y/sqrt(mean(y.^2));
	y = reshape(y,m,n);
	ys(:,i) = y;
