function yn=is_odd(a)

yn=rem(a,2);