jcd('Jims_working_disc:Jims_Matlab5_files:ICA:ICA_ST_WITH_SCALINGS:ICA_ST_WM:');
cd
