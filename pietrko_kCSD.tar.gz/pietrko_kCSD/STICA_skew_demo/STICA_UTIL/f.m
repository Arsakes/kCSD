function f(n);

figure(n);