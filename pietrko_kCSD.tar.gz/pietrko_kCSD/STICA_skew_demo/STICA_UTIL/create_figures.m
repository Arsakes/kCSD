function create_figures;

% Put figures in correct location on screen.

s=300;
offset=10;

jfig(1);
p=get(gcf,'Parent');
%[fhfw]=get(p,'TerminalDimensions'); % Causes glitch on some machines.
%fw=fhfw(1);fh=fhfw(2);
[w h]=jget_screensize;fw=w;fh=h;

jfig(1,s,s,w-s,h-fh);
fh1=2*fh+offset;
jfig(2,s,s,w-s,h-fh1);

fw1=2*s+offset;
jfig(3,s,s,w-fw1,h-fh);
jfig(4,s,s,w-fw1,h-fh1);

% Cross section.
fh1=fh+offset;
jfig(10,s,s,w-3*s,h-fh1);
