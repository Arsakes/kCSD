function op=jgauss(ip,sd);

% USE JGAUSS_WRAP!

% Smoothes values in ip array using wrap-around.

% Make Gaussian mask for smoothing.
% ip = rand(1,20);

N = length(ip);

x = linspace(-3,3,N); 	% mask is same length as input array.
mask = exp(-(x.*x)/(2*sd*sd));
mask = mask/sum(mask);

%plot(mask); pause;

op = zeros(1,N);
for i=1:N
	% shift mask along by one element.
	x=jmat_h_shift(ip,i);
	res = dot(x,mask);
	op(i)=res;
end;
op=jmat_h_shift(op,floor(N/2)+1);
op=reverse(op');
op = op';
%plot(ip);pause;plot(op);
