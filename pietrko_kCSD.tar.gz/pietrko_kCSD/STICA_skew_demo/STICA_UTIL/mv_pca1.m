function [pcs, evals]=mv_pca1(mv1,neig);

% mv1 is a nrxncxnt array of images.
% nr*ncx1 pcs are in columns of pcs matrix.

% Do pca on images.
[nr nc nt]=size(mv1);
mv1=mv_stripmean(mv1);
mv2=reshape(mv1,nr*nc,nt);
clear mv1;
c=mv2*mv2'; 

[pcs evals]=eigr(c);

pcs=pcs(:,1:neig);
%evals=diag(evals);
evals = evals(1:neig,1:neig);

if neig==2
	xy = pcs'*mv2;
	f(2);clf;plot(xy(1,:),xy(2,:),'.');
	title('mv_pca1: Projection onto principal components'); axis equal;
end;