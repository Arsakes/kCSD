function jload(fname);

s=['load ' eval('fname')]

s
% eval(s);

a