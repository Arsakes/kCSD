function m0=jmat_h_shift(m1,shift1)
% Shift elements of matrix left/right by shift units, with wraparound.

if shift1==0
	m0=m1;
	return;
end;

shift = floor(shift1); % Get odd result if shift in float.

if (shift1-shift>0)
	error('jmat_h_shift: shift not integer');
end;

[m n]=size(m1);

if shift>0
	m0 = m1(:,1:n-shift); 
	m0 = [m1(:,n-(shift-1):n),m0];
else
	m0 = m1(:,n-shift:n); 
	m0 = [m0,m1(:,1:n-(shift-1))];
end;

