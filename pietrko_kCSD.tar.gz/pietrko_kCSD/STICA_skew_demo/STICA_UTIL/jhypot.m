function len=jhypot(x,y);

len = sqrt(x.*x + y.*y);