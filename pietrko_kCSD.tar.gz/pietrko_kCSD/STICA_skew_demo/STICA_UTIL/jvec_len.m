function len=jvec_len(v);

len = sqrt(dot(v,v));