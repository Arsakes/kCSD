function v=jshuffle(v);

n=length(v);
i=randperm(n);
v=v(i);