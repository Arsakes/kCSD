jcd('Jims_working_disc:Jims_Matlab5_files:ICA:EEG:MAKEIG_MATLAB_FILES:MAKEIG_EEG:');
cd
