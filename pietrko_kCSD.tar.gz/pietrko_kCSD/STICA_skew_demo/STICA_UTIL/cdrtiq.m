jcd('Jims_working_disc:Jims_Matlab5_files:PSYCHOPHYSICS:MAKE_EXPTS:RT_IQ:');
cd
