 function [ps, disparities] = jmake_stereoW(image_len,num_pairs,noise,disp_max);

% Returns num_pairs 1D vectors, each of which contains an image pair.
% This uses wrap-around for each image.
% eg [ps, disparities] = temp(10,100,1);

plt=1; % plot arrays.

if nargin==3
	disp_max = 1;
end;

fprintf('jmake_stereoW: \nnum_pairs = %d \nmaxdisparity = %.3f\nImage length = %d\n',num_pairs,disp_max,image_len);

rho = 0.2;
sd = 1;

x = linspace(0,2*pi,num_pairs);
disparities = sin(x);
disparities = disparities*disp_max;

% plot(disparities); pause;

ps = zeros(image_len*2,num_pairs);

surface_len = image_len*num_pairs + num_pairs*image_len;
surface = texture1D(surface_len,rho);
% surface = jgauss_wrap(surface,sd);

index = 1;
for i=1:num_pairs
	disp = disparities(i);
	fprintf('i=%d disp=%.3f\n',i,disp);
	% Pick position at random.
	% index = floor( rand * (surface_len-image_len-1));

	index = index + image_len;
	a = surface(index:index+image_len-1)';
	% Ensure that a is non-zero.
	while sum(a)==0
		index = index + image_len;
		a = surface(index:index+image_len-1)';
	end;

	% Gauss this region with wrap.
	a = jgauss_wrap(a',sd); a= a';

	i1 = jshift_wrapR(a,-disp/2);i2 = jshift_wrapR(a,disp/2);

	i1 = jzmean_uvar(i1); i2 = jzmean_uvar(i2);

	p = [i1,i2];
	% add noise
	if noise>0
		p = p + randn(1,image_len*2)*noise;
	end;

if plt
s=3;
i1 = jshift_wrapR(i1,s);
i2 = jshift_wrapR(i2,s);
plot(i1); axis([1 image_len -2 2]); hold on;  plot(i2,'r'); hold off;drawnow; press_return;
end;

	ps(:,i) = p';
end;

%jcludge('jmake_stereoW');figure(1);plot(ps(1,:)); pr;

% Make max value == 1.
% ps=ps/max(max(ps));
ps = ps';

% reduce mag of inputs.
% ps = ps/10;

fprintf('... DONE.\n');




function b=temp();

b=rand;
if b<0.5 b=temp; end;