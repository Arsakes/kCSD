function jset_title_size(s);

t=get(gca,'Title');
set(t,'FontSize',s);