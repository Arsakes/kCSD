function r=jcorr_info(x0,y0,order);

% find Nth order corrs coeff of x,y.

if nargin==2
	order=10;
end;

n = length(x0);

r=0;
for k=2:order
	y=y0;
	y = y.^k;
	y = y-mean(y);
	for j=2:order
	x = x0; 
	x = x.^j;
	x = x-mean(x);

	cov = mean(x.*y) - mean(x)*mean(y);

	xstd = std(x);
	ystd = std(y);

	r1 =  cov/(xstd*ystd);
	r = r + r1*r1;
	end;
% fprintf('k=%d r1=%.3f\n',k,r1);
end;

r = sqrt(r); % /(pi+0.02);
r=r/2;
