function im2=mv_stripmean(im1);

% Remove mean image from movie.

% im1  = input ni x nj x nt array
% type = 's'  remove space mean
%        't'  remove time mean
%        'st' remove both
%
% im2  = output ni x nj x nt array

[ni, nj, nt] = size(im1); npix = ni*nj*nt;

m = mv_get_mean(im1);

im2=im1;
for i=1:nt
	im2(:,:,i) = im1(:,:,i)-m;
end;

% im2 = reshape(im2, ni, nj, nt);

