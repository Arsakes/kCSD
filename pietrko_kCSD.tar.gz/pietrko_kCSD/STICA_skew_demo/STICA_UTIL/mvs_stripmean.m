% function im1 = mvs_stripmean(mv)

% Remove mean movie from set of movies.

% function stripmean(im1, type)
%
% remove space/time means from image block
%
% im1  = input ni x nj x nt array
% type = 's'  remove space mean
%        't'  remove time mean
%        'st' remove both
%
% im2  = output ni x nj x nt array

[nr, nc, nframes, nt] = size(mv);

mv_mean = zeros(nr,nc,nframes);

for t=1:nt
	mv_mean = mv_mean + mv(:,:,:,t);
end;
	
mv_mean = mv_mean/nt;

for t=1:nt
	mv(:,:,:,t) = mv(:,:,:,t) - mv_mean;
end;

