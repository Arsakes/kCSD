function [xi, yi] = make_spline_wrap(N,numcp)

% Make a spline that wraps around so that
% yi(1)==yi(N), using numcp RANDOM control points.
% The values of y are between 0 and 1,
% but spline may take values of yi outside this
% range. Have included a check on this.
%  e.g. [x y]=make_spline_wrap(90,3);

xxx 	= 1:numcp*3;
y 	= rand(1,numcp);
yyy 	= [y,y,y];

% MUST START FROM ZERO.
xi=linspace(0,numcp*3,3*N);

yi=interp1(xxx,yyy,xi,'spline');

% f(1);clf;plot(xxx,yyy,'o',xi,yi);grid on;pr;

yi = interp1(xi,yi,xi(N+1:2*N));

% CHECK RANGE OF Yi is 0-->1. IF IT ISNT THEN DO AGAIN.
[ymin ymax]=jminmax(yi);
if ymin<0 |  ymax>1
	% fprintf('RECURSE ...\n');
	[xi, yi] = make_spline_wrap(N,numcp);
end;

% shift = round(rand*N);
% shift
% yi=jshift_wrap(yi,shift);
xi=1:N;

% f(1);plot(yi);  jsize(yi,'yi'); yi=jshift_wrap(yi,45);  jsize(yi,'yi');xi=jshift_wrap(xi,45); f(2); plot(yi); pr;

% f(2);clf;plot(yi);grid on;

% CHECK
% y2=jshift_wrap(yi,45);
% f(3);plot(y2);grid on;

