 set(gca,'Projection','perspective'); 
 % See also jset_view_angle.m