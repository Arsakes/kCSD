function jprint_mat(m,fp,comment);

% PRINT USING TABS.

if nargin<2 fp = 1; end;
if nargin>2 fprintf(fp,'\n\n%s\n',comment); end;

[nr nc]=size(m);

str=[];
a='%.6f\t';
for i=1:nc str=[str a]; end;
str=[str '\n'];

fprintf(fp,str,m');

% MEANS
fprintf(fp,'Column_means\n');
fprintf(fp,str,mean(m));
fprintf(fp,'\n');

% STANDARD DEVS
fprintf(fp,'Column_standard_devs\n');
fprintf(fp,str,std(m));
fprintf(fp,'\n\n');
