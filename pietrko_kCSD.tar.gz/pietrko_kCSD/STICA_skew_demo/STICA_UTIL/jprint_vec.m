function jprint_vec(m,fp,comment)

% PRINT USING TABS.

if nargin<2 fp = 1; end;
if nargin>2 fprintf(fp,'\n\n%s\n',comment); end;

[nr nc]=size(m);
if nc==1 m=m'; [nr nc]=size(m); end;

str=[];
a='%.3f\t';
for i=1:nc str=[str a]; end;
str=[str '\n'];

fprintf(fp,str,m');

return;

% MEANS
fprintf(fp,'Column_means\n');
fprintf(fp,str,mean(m));
fprintf(fp,'\n');

% STANDARD DEVS
fprintf(fp,'Column_standard_devs\n');
fprintf(fp,str,std(m));
fprintf(fp,'\n\n');
