function v0 = jshift_wrapR(v1,shift);

% Linear interpolate to get real values of shift with wrap-around.

% See test_jshift_wrapR for tester program.

if abs(shift)<1e-7
	v0=v1;
	return;
end;

shift = -shift; % Got sign wrong below!

len = length(v1);

% Shift by integer amount.
if abs(shift)>1
	ishift = floor(shift);
	if shift>0
		v1 = [v1(ishift+1:len) v1(1:ishift)];
	else
		s = -ishift;
		v1 = [v1(len-s+1:len) v1(1:len-s) ];
	end;
	% Get remainder of shift to be done ...
	shift = shift-ishift;
	% if ishift<0 shift = 1-shift; end; % Because floor(-1.6)=-2.
end;

% Now shift v1 by fractional amount.

if shift==0
	v0=v1;
else
if shift>0
% Shift v1 by +1.
	v2 = [v1(2:len) v1(1)]; % = [b c d a]
else
% Shift v1 by -1 and alter sign of shift.
	v2 = [v1(len) v1(1:len-1) ]; % = [d a b c]
	shift = -shift;
end;
v_diff = v2-v1; % v_diff is gradient of grey-levels in v1.
v0 = v1 + shift*v_diff;
 
end;

