function r=deg2rad(d);

r=d/57.29577951;
