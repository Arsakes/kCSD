function xr = jrandphase(x)

% Written by JP - mods by jvs.
% yeuk! find out how to do this nicely
% NB: it applies *same* randomisation to all columns of x

i = sqrt(-1);
[n, k] = size(x);

if n==1
	error('jrandphase: need column vector');
end;

fx = fftshift(fft(x));
if rem(n, 2) == 0
    fx = fx(n/2+1:-1:1, :);
else
    fx = fx((n+1)/2:-1:1, :);
end
m = size(fx, 1);


if rem(n, 2) == 0
    r = repmat(rand(m-2, 1), 1, k);
    fx(2:m-1, :) = exp(2*pi*i*r).*fx(2:m-1, :);
else
    r = repmat(rand(m-1, 1), 1, k);
    fx(2:m, :)   = exp(2*pi*i*r).*fx(2:m, :);
end

if rem(n, 2) == 0
    fx = [fx(m:-1:1, :); conj(fx(2:m-1, :))];
else
    fx = [fx(m:-1:1, :); conj(fx(2:m, :))];
end

% xr = ifft(ifftshift(fx));
xr = real(ifft(ifftshift(fx))); % removes very small -ve imag. parts

% bit of code to test it works
% x = randn(128, 1); y = randphase(x);
% figure(1); clf;
% subplot(2, 1, 1); plot(abs(fft(x)));
% subplot(2, 1, 2); plot(abs(fft(y)));
