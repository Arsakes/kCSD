function [U,D,V]  = mv_svd(images,K)

% function [U D V] = mv_svd(images)
%
% SVD of image block
% assumes appropriate means already removed (see stripmean)
%
% images   = input ni x nj x nt array
% K = number of retained 'eigenvectors'.

% Now images is an array of M rows (pixels) and N columns (time steps).
% So each column of images is an image.

[nr nc nt]=size(images);
images = reshape(images,nr*nc,nt);

% jsize(images);pr;
[U D V]=svd(images,0); % The 0 ensures that only N singular values are computed.

% Now images = U*D*V';

D

% Set all but K singular values to zero.
[N N]=size(D);
for i=K+1:N
	D(i,i)=0;
end;

D

% Remove redundant part of D.
D = D(1:K,1:K);

% Remove redundant columns from U.
U = U(:,1:K);

% Remove redundant columns of V.
V = V(:,1:K);

jsize(U,'U');
jsize(D,'D');
jsize(V,'V');

% Check residual.
I = U*D*V';
residual=norm(I(:)-images(:))/length(images(:));
residual

