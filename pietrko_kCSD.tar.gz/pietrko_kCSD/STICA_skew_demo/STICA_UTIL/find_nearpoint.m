function [p, i, j] =find_near_point;

% Sets view to 0,0 and then finds 3d point
% nearest to viewer; which is given by smallest
% value of y.

view(0,0);
h = get(gca, 'Children');x=get(h,'xdata');y=get(h,'ydata');z=get(h,'zdata');
ymin=min(y(:));
ymax=max(y(:));
yrange = ymax-ymin;

[i j]=find(y==ymin);

[r c]=size(x);
i=mod(i-1,r);
%j=mod(j+10,r);

% CLUDGE
% 40, 40
i=50;
j=50;

% x(i,j) = 0;
% y(i,j) = ymax;
% z(i,j)=0;

p = [x(i,j), y(i,j), z(i,j)];


i
j