jcd('Jims_working_disc:Jims_Matlab5_files:MATLAB_UTIL:JUTIL:');
cd
