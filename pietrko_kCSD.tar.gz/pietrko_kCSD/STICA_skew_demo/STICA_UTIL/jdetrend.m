function [res, m, bias]=jdetrend(y,x);

% Remove linear effect of x on y. x and y must be col vecs.

% y=1:100;y=y+randn(1,100)*10;plot(y); x=1:100; [yy m bias]=jdetrend(y,x);plot(yy);

x=is_col_vec(x);
y=is_col_vec(y);

% Given y = mx + bias solve for vector x and scalar bias.
[m bias]=jaffinesolve(x,y);

% Find what y would have been in absence of x - leave bias, this is mean of y.
res=(y-m*x);
