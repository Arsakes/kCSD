% read_buchel_data;

load res_UDV;
neig=10;
