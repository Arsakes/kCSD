% Select number of eig vecs sufficient to account for x% of data variance.

pcs=U;pct=V;sval=D;

x=0.95;     % (95% of variance)

evals = diag(sval).^2;  % eval (variance) is square of sval
tot_sval = sum(evals(:));
num_evals = length(evals);

f(5);clf;plot(cumsum(evals)); 
title('eigenvalues');

sub_tot = 0;
for i=1:num_evals
	sub_tot = sub_tot + evals(i);
	prop = sub_tot/tot_sval;
	if i==neig neig_prop = prop;end;
	if prop>=x; nx=i; end;
end;

fprintf('neig=%d eigs accounts for %.3f of the data\n',neig,neig_prop);
fprintf('Number of evecs required to account for ' num2str(100*x) '% of data variance = %d\n',nx);
