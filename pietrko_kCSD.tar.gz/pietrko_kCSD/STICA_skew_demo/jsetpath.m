% jsetpath

a=computer;
if strcmp(a(1:3),'MAC') % MAC
	sep = '';
elseif strcmp(a(1:2),'PC') % PC
   sep = '\';
else % Assume unix
	sep='/';
end;

old=cd;

a=cd;
eval(['addpath ' a sep 'STICA_UTIL']);

jaddpath([a sep 'STICA_FIND_VU_FAST']); 
jaddpath([a sep 'STICA_CONJ_GRAD']);
jaddpath([a sep 'STICA_CORE']);
jaddpath([a sep 'STICA_NIPS_ADDD_ONS']);

% jcd(old);

fprintf('Path now set.\n');
