% go_timax_multvariate;
% Uses cov matrices but not gradients to find max.

% Find covariance matrix Vx and Ux of input unit states.

% W=W_best+10*randn(2,2); W=W(:);F = find_FoneD_ICA_TIMAX(W,Ux,Vx,num_op_units,num_mixtures)

global disparities W W1 W2 Data disparities old_W Data1 zs;
global mixtures count Fs W_global W_best Fminval lambda;

lambda = 10;
Fminval=10000;
count=0;
jrand_set_seed(989);

% Use data_init for first call.
data_init_multivariate; 

jsize(mixtures,'mixtures');

shf = 2;
lhf = 900;

[num_mixtures num_samples] = size(mixtures); % one mixture per row.

[Ux Vx]=get_UxVx(mixtures,shf,lhf);

num_op_units = 3;

W = randn(num_op_units,num_mixtures);
% W(1,:)=W(2,:);

W = W_best + randn(size(W_best));
% W = eye(size(W_best));
W0 = W(:);

Fs=[];
W = fmins('find_FoneD_ICA_TIMAX',W0,foptions,[],Ux,Vx,num_op_units,num_mixtures);

% F = find_FoneD_ICA_TIMAX(W1D,Ux,Vx,num_op_units,num_mixtures);

% W = reshape(W1D,num_op_units,num_mixtures);
ys=W_global*mixtures;

for i=1:num_op_units
	i
	y=ys(i,:);
	soundsc(y);
	pr;
end;
jcorr(ys(1,:),s(1,:))
jcorr(ys(1,:),s(2,:))
jcorr(ys(2,:),s(1,:))
jcorr(ys(2,:),s(2,:))
