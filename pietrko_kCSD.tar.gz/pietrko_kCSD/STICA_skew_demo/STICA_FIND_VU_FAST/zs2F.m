function [U, V, F,s_zmeans,l_zmeans]=zs2F(zs,shf,lhf);

% Compute F=log(V/U) from output values array zs.

global l_diffs s_diffs;

plt=0;
[s_zmeans l_zmeans] = smooth_zs(zs,shf,lhf);

% Find difference between z and zmean at each time step.
l_diffs = l_zmeans - zs;
s_diffs = s_zmeans - zs;

% Find new V and U values.
V = dot(l_diffs,l_diffs)/2;
U = dot(s_diffs,s_diffs)/2;
F = log(V/U);
%fprintf('zs2F: V=%.3f		U=%.3f 		F=%.3f\n',V,U,F);

if plt
figure(1);jplot2vecs(zs,s_zmeans,'zs+s_zmeans');
figure(2);jplot2vecs(zs,l_zmeans,'zs+l_zmeans');
figure(3);jplot2vecs(s_zmeans,l_zmeans,'s_zmeans+l_zmeans');
%[zs; s_zmeans]'
%pr;
end;
