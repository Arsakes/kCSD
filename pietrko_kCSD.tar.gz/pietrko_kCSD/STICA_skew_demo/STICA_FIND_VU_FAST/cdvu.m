jcd('Jims_working_disc:Jims_Matlab5_files:TIMAX:TIMAX_ICA:FIND_VU_FAST:');
cd
