% Initialise values for timax net.
% timax_init only specifies the net, not the training data.

global max_mask_len mask_half_lives CHECK_VU_RATIO CHECK_V CHECK_U cludge_mask image_len num_ip_vecs W1 W2 BP targets bias_state linear_h_units zs2 batch_length num_ip_units num_h_units num_op_units shf lhf VU_ratios old_zs s_lambda l_lambda W1 W2 W linear_op_units biased_op_units surface_made;

% PARAM VALUES
shf 		= 32;
lhf 		= 1e2*shf;
mask_half_lives = 10;
max_mask_len = num_ip_vecs;
batch_length = num_ip_vecs;

% BOOLEANS
surface_made = 0;
CHECK_V		= 0;
CHECK_U		= 0; % extremise U.
CHECK_VU_RATIO 	= 0;
BP		= 0;% Dont use temporal process, use targest as targets.
jtrace								= 0;

biased_op_units = 0;
linear_h_units 	= 0;
linear_op_units = 1;
bias_state 	= 1; % normally = 1.
cludge_mask			= 0; % Look in jmake_mask.

% NETWORK ARCH ...
num_ip_units = image_len*2;
num_h_units = 10;
num_op_units = 1;
timax_arch = [num_ip_units num_h_units num_op_units  ]; 

% Normalise wts according to fan-in.
W1=W1/num_h_units;
W2=W2/num_ip_units;

% Set short and long half-lives.
s_lambda =  half_life2lambda(shf);
l_lambda =  half_life2lambda(lhf);

% Make exponential masks.

%[s_mask s_mask_len] = jmake_mask(shf,mask_half_lives,batch_length);
%[l_mask l_mask_len] = jmake_mask(lhf,mask_half_lives,batch_length);

% Make exponential masks for derivs.
%s_deriv_mask = s_mask; 
%s_deriv_mask(s_mask_len) = -1;
%l_deriv_mask = l_mask; 
%l_deriv_mask(l_mask_len) = -1;

% Make wt matrices. Each row is the wt vec of an op unit.
% The bias of an op unit is given by the sum of 0th elements in W and WW.

% Store one layer state per column.
xs = zeros(num_ip_units,batch_length);
ys = zeros(num_h_units,batch_length);
zs = zeros(num_op_units,batch_length);

% Declare units
hidden		= jcol_vec(num_h_units);
output		= jcol_vec(num_op_units);

net_hid	= jcol_vec(num_h_units);
net_out	= jcol_vec(num_op_units);

delta1 	= jcol_vec(num_h_units);
delta2	= jcol_vec(num_op_units);

W1_deriv=[];
W2_deriv=[];

s_mask = [];
l_mask=[];
Vs=[];
Us=[];
VU_ratios=[];
old_s_diffs=[];
old_l_diffs=[];
old_zs=[];
last_W1_change = 0;
last_W2_change = 0;
old_W=[];
old_zs=[];
zs2=[];

%print_params;
fprintf('NET: ip=%d h=%d op=%d\n',num_ip_units,num_h_units,num_op_units);
fprintf('short_hl=%d long_hl=%d mask_half_lives=%d\n',shf,lhf,mask_half_lives);

if CHECK_U fprintf('CHECK_U==1\n'); pr; end;
if CHECK_V fprintf('CHECK_V==1\n'); pr; end;
if CHECK_VU_RATIO fprintf('CHECK_VU_RATIO==1\n'); pr; end;

%%%%%%%%%%%%%% EOF %%%%%%%%%%%%%%%%%%%
