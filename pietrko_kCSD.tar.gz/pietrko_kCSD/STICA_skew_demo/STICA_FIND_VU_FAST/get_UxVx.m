function [Ux, Vx]=get_UxVx(mixtures,shf,lhf);

% Find covariance Vx and Ux of input unit states.
% Ux and Vx are matrices of num_mixtures x num_mixtures.
% Each entry ij is the covariance between input i and j -
% with U having short-term vars and V having long-term vars.
% One mixture per row.
% Called from:
% function F = find_FoneD_ICA_TIMAX(W1D,Ux,Vx,num_op_units,num_mixtures);
% W = reshape(W1D,num_op_units,num_mixtures);
% U = W*Ux*W'; V = W*Vx*W';
% Corresponds to causal_model in JP code.

global mask_half_lives max_mask_len;

%fprintf('get_UxVx ...\n');

max_mask_len = 1000;
mask_half_lives = 4;

[num_mixtures num_samples] = size(mixtures); % one mixture per row.

%jsize(mixtures,'mixtures');
%fprintf('num_mixtures=%d num_samples=%d\n',num_mixtures, num_samples);

x=1:num_samples;

Vx = zeros(num_mixtures);
Ux = zeros(num_mixtures);

for i=1:num_mixtures
	xi = mixtures(i,:);
	[xi_smeans xi_lmeans] = smooth_zs(xi,shf,lhf);

	% Find difference between z and zmean at each time step.
	xi_ldiffs = xi_lmeans - xi;
	xi_sdiffs = xi_smeans - xi;
	
	% f(3);  subplot(2,1,1);plot(x,xi_smeans,x,xi);title('Mixtures');
	% subplot(2,1,2);plot(x,xi_lmeans,x,xi);
	
	for j=i:num_mixtures
			xj = mixtures(j,:);
			[xj_smeans xj_lmeans] = smooth_zs(xj,shf,lhf);

			% Find difference between z and zmean at each time step.
			xj_ldiffs = xj_lmeans - xj;
			xj_sdiffs = xj_smeans - xj;
	
			Vij = dot(xi_ldiffs,xj_ldiffs)/num_samples;
			Uij = dot(xi_sdiffs,xj_sdiffs)/num_samples;
			
			Vx(i,j) = Vij;	Vx(j,i) = Vij;
			Ux(i,j) = Uij;	Ux(j,i)= Uij;			
		end;
	end;

%	Vx
%	Ux
%fprintf('...get_UxVx\n');
