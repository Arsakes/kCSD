function [s_zmeans, l_zmeans] = smooth_zs(zs,hs,hl);

% Find exp weighted z-values.
% Base first z_tilde on previous value of z_tilde.

global max_mask_len mask_half_lives batch_length;

%-------------------------------------------

% Make masks for temporal smoothing.
% Mask increases exponentially up to penultimate index, final mask entry is zero to
% ensure that current z does not contribute to zmean.
% n=num half lives in mask.

n = mask_half_lives; 	
%if s_mask==[]																	
[s_mask s_mask_len]= jmake_fmask(hs,n,max_mask_len);
[l_mask l_mask_len] = jmake_fmask(hl,n,max_mask_len);

%fprintf('smooth_zs: hsf=%d lhf=%d\n',hs,hl);
%fprintf('s_mask_len=%d l_mask_len=%d\n',s_mask_len,l_mask_len);
%jcludge('smooth_zs'); l_mask = ones(size(l_mask)); l_mask(l_mask_len)=0; l_mask = l_mask/sum(l_mask);
% figure(4); plot(s_mask); hold on; plot(l_mask); hold off;

%-------------------------------------------

s_zmeans = jconv_timax(zs,s_mask);
l_zmeans = jconv_timax(zs,l_mask);

%-------------------------------------------

