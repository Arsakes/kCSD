function [mask, t] = jmake_mask(half_life, n, max_mask_len)

% Make exponential mask containing n half-lives of data.

%fprintf('jmake_mask ...\n');pr; half_life  n max_mask_len

% Set mask length.
t = n*half_life;
t = min(t,max_mask_len);
if nargin>3 if mask_len>0 t=mask_len; end; end;

lambda = half_life2lambda(half_life);

% make array of lambda and raise each to power in temp.
temp = [0:t-1]';
lambdas = ones(t,1)*lambda;
mask = lambda.^temp;

mask = jreverse(mask);

% Set final element == 0 if zk not element of zk_mean.
mask(t)=0;

% Plot mask.
% figure(1);plot(mask);



