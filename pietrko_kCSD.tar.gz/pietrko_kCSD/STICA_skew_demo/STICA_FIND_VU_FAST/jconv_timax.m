function s=jconv_timax(image,mask);

% Use filter to do convoution.
% Filter does not use wrap-around so make 3 contiguous versions
% of image and filter this, then extract centre image.

bounds= size(image);
if bounds(2)==1
	image = image';
end;

n = length(image);
y = [image,image,image];

%dummy = mean(image)*ones(size(image));y = [dummy,image,dummy];
%y = [image(n-1),image(1:n-1),image,image(2:n),image(2)];

mask = jreverse(mask);

% FILTER ...
s=filter(mask,1,y);

% Extract central image ...
s=s(n+1:2*n);

if bounds(2)==1
	s = s';
end;
%figure(2); jplot2vecs(y,s); 
