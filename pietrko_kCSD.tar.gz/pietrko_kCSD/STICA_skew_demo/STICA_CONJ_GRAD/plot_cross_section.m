function plot_cross_section(fun,w0,data,s,alpha,n);

% Plot cross section of function in direction s.
%----------------------------------------------------------------------------------%
% 27/5/99 JV Stone, Psychology Department, Sheffield University, Sheffield, England.    
%----------------------------------------------------------------------------------%

if nargin<6
	n = 5;
end;

%w_inc = 4*alpha*s;
% w0 = w0+w_inc;

count=0;
ws=[];
for i=-n:n
	count=count+1;
	w_inc = i*alpha*s*2;
	w = w0+w_inc;
	f = feval(fun, w, data);
	fs(count)=f;
	ws=[ws i];
end;

figure(10); % arect = [0.1 0.1 0.9 0.9]; set(gca,'Position',arect);
plot(ws,fs); grid on;
title('Conj Grad: Cross section of function');
xlabel('Distance in parameter space (0 corresponds to current estimated minimum).');
ylabel('Function value');
drawnow;
