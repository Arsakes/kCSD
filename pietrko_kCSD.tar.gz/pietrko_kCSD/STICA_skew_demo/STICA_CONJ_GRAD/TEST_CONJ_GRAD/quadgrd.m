function g = quadgrd(x)

g = [100; 1].*x;