function y = quadfun(x)

y = 0.5*(100*x(1)^2+x(2));