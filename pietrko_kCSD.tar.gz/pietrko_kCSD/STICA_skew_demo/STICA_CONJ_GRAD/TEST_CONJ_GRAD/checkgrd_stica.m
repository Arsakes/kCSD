function checkgrd_stica(w,data, fun, grd, df)

% checkgrd_stica(w0,data,'basicfg_skew','basicfg_skew', 0.1)
% checkgrd_stica(w,fundat,'basicf_skew','basicg_skew', randn(20,1))
% checkgrd_stica(w(:),fundat,'basicf_skew','basicg_skew', 0.1)

x=w;
% w=reshape(w,5,4);
f = feval(fun, w);
g1 = feval(grd, w);
jsize(g1,'g1');
dx = df/norm(g1);
n = length(x); 
z = zeros(n, 1); 
g2 = z;

for i = 1:n
   e = z; e(i) = 1;
	%jsize(x,'x');jsize(dx);jsize(e);
   g2(i) = (feval(fun, x+dx/2*e) - feval(fun, x-dx/2*e))/dx;
end

[g1 g2]
norm(g1-g2, 1)
